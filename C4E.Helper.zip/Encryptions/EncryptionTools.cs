﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace C4E.V4.Common.Utils
{
    public static class EncryptionTools
    {

        #region _AesCryptoServiceProvider
        private static void _AesCryptoServiceProvider()
        {
            string original = "Here is some data to encrypt!";
            using (AesCryptoServiceProvider myAes = new AesCryptoServiceProvider())
            {
                myAes.KeySize = 256;
                // Encrypt the string to an array of bytes. 
                byte[] encrypted = EncryptStringToBytes_Aes(original, myAes.Key, myAes.IV);

                // Decrypt the bytes to a string. 
                string roundtrip = DecryptStringFromBytes_Aes(encrypted, myAes.Key, myAes.IV);

                //Display the original data and the decrypted data.
                Console.WriteLine("Original:   {0}", original);
                Console.WriteLine("Round Trip: {0}", roundtrip);
            }


        }




        public static byte[] EncryptStringToBytes_Aes(string plainText)
        {
            byte[] iv = new byte[] { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                                           0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F};
            byte[] key = new byte[] { 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
                                           0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF };

            return EncryptStringToBytes_Aes(plainText, key, iv);

        }
        public static byte[] EncryptStringToBytes_Aes(string plainText, byte[] Key, byte[] IV)
        {
            // Check arguments. 
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("Key");
            byte[] encrypted;
            // Create an AesCryptoServiceProvider object 
            // with the specified key and IV. 
            using (AesCryptoServiceProvider aesAlg = new AesCryptoServiceProvider())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for encryption. 
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {

                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            // Return the encrypted bytes from the memory stream. 
            return encrypted;
        }

        public static string DecryptStringFromBytes_Aes(byte[] cipherText, byte[] Key, byte[] IV)
        {
            // Check arguments. 
            if (cipherText == null || cipherText.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("IV");

            // Declare the string used to hold 
            // the decrypted text. 
            string plaintext = null;

            // Create an AesCryptoServiceProvider object 
            // with the specified key and IV. 
            using (AesCryptoServiceProvider aesAlg = new AesCryptoServiceProvider())
            {
                aesAlg.Key = Key;
                aesAlg.IV = IV;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for decryption. 
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {

                            // Read the decrypted bytes from the decrypting stream 
                            // and place them in a string.
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }

            }

            return plaintext;

        }


        #endregion


        #region CryptAlgorithm
        // The chryptographic service provider we're going to use
        private static TripleDESCryptoServiceProvider _CryptAlgorithm = null;

        /// <summary>
        /// Gets the crypt algorithm.
        /// </summary>
        /// <value>The crypt algorithm.</value>
        private static TripleDESCryptoServiceProvider CryptAlgorithm
        {
            get
            {
                if (_CryptAlgorithm == null)
                    _CryptAlgorithm = new TripleDESCryptoServiceProvider();
                return _CryptAlgorithm;
            }
        }
        #endregion

        #region CryptKey
        /// <summary>
        /// Gets or sets the key of the alogritm.
        /// </summary>
        /// <value>The key.</value>
        public static string CryptKey
        {
            get
            {
                return Convert.ToBase64String(CryptAlgorithm.Key);
            }
            set
            {
                CryptAlgorithm.Key = Convert.FromBase64String(value);
            }
        }
        #endregion

        #region CryptVector
        /// <summary>
        /// Gets or sets the vector of the alogritm.
        /// </summary>
        /// <value>The key.</value>
        public static string CryptVector
        {
            get
            {
                return Convert.ToBase64String(CryptAlgorithm.IV);
            }
            set
            {
                CryptAlgorithm.IV = Convert.FromBase64String(value);
            }
        }
        #endregion

        #region GenerateKeyAndVector
        /// <summary>
        /// Generates the key and vector.
        /// </summary>
        private static void GenerateKeyAndVector()
        {
            ///Generate new Vector and key
            CryptAlgorithm.GenerateIV();
            CryptAlgorithm.GenerateKey();
        }
        #endregion

        #region EncryptString
        /// <summary>
        /// Encrypts the string.
        /// </summary>
        /// <param name="Value">The value.</param>
        /// <param name="key">The key.</param>
        /// <param name="vector">The vector.</param>
        /// <returns></returns>
        public static string EncryptString(
            string Value,
            string key,
            string vector)
        {
            ///Store the new key in the out key param
            CryptKey = key;
            ///Store the new vector in the out vector param
            CryptVector = vector;
            ///Encrypt and return the encrypted string
            return EncryptString(Value);
        }
        /// <summary>
        /// Encrypts the string.
        /// </summary>
        /// <param name="Value">The value.</param>
        /// <param name="key">The key.</param>
        /// <param name="vector">The vector.</param>
        /// <returns></returns>
        public static string EncryptString(
            string Value,
            out string key,
            out string vector)
        {
            ///Create new key and vector
            GenerateKeyAndVector();
            ///Store the new key in the out key param
            key = CryptKey;
            ///Store the new vector in the out vector param
            vector = CryptVector;
            ///Encrypt and return the encrypted string
            return EncryptString(Value);
        }
        /// <summary>
        /// Encrypts the string.
        /// </summary>
        /// <param name="Value">The value.</param>
        /// <returns>Encrypted string</returns>
        public static string EncryptString(
            string Value)
        {
            ///Declare all required resourses
            MemoryStream ms;
            CryptoStream cs;
            byte[] byt;
            ///Traslate string to bytes in UTF8 format
            byt = Encoding.UTF8.GetBytes(Value);
            ///Create new memmory stream to store the encrypted data
            ms = new MemoryStream();
            ///Create the crypto stream
            cs = new CryptoStream(ms, CryptAlgorithm.CreateEncryptor(), CryptoStreamMode.Write);
            ///Write the data to stream
            cs.Write(byt, 0, byt.Length);
            ///Flush final block is needed for the encryption last block
            cs.FlushFinalBlock();
            ///Close the crypto stream
            cs.Close();
            ///Return the string translaterd fom the bytes in the stream
            return Convert.ToBase64String(ms.ToArray());
        }
        #endregion

        #region DecryptString
        /// <summary>
        /// Decrypts the string.
        /// </summary>
        /// <param name="Value">The value.</param>
        /// <param name="key">The key.</param>
        /// <param name="vector">The vector.</param>
        /// <returns>Decrypted string</returns>
        public static string DecryptString(
            string Value,
            string key,
            string vector)
        {
            ///Set key to alogritm object
            CryptKey = key;
            ///Set vector to alogritm object
            CryptVector = vector;
            ///Get the decrypted string
            return DecryptString(Value);
        }
        /// <summary>
        /// Decrypts the string.
        /// </summary>
        /// <param name="Value">The value.</param>
        /// <returns>Decrypted string</returns>
        public static string DecryptString(string Value)
        {
            ///Declare all required resourses
            MemoryStream ms;
            CryptoStream cs;
            byte[] byt;
            ///Translate the string to bytes From Base64
            byt = Convert.FromBase64String(Value);
            ///Create new memmory stream to store the decrypted data
            ms = new MemoryStream();
            ///Write the decrypted data to stream
            cs = new CryptoStream(ms, CryptAlgorithm.CreateDecryptor(), CryptoStreamMode.Write);
            cs.Write(byt, 0, byt.Length);
            cs.FlushFinalBlock();
            ///Close the crypto stream
            cs.Close();
            ///Return the decrypted stream and translate it to string in UTF8 format
            return Encoding.UTF8.GetString(ms.ToArray());
        }
        #endregion

        #region EncryptFile
        /// <summary>
        /// Encrypts the file.
        /// </summary>
        /// <param name="clearFile">The clear file.</param>
        /// <param name="encryptedFile">The encrypted file.</param>
        /// <param name="key">The key.</param>
        /// <param name="vector">The vector.</param>
        public static void EncryptFile(
            string clearFile,
            string encryptedFile,
            string key,
            string vector)
        {
            ///Set algoritm Vector and Key
            CryptKey = key;
            CryptVector = vector;
            ///Encypt the file
            EncryptFile(clearFile, encryptedFile);
        }
        /// <summary>
        /// Encrypts the file.
        /// </summary>
        /// <param name="clearFile">The clear file.</param>
        /// <param name="encryptedFile">The encrypted file.</param>
        /// <param name="key">The key.</param>
        /// <param name="vector">The vector.</param>
        public static void EncryptFile(
            string clearFile,
            string encryptedFile,
            out string key,
            out string vector)
        {
            ///Create new key and vector
            GenerateKeyAndVector();
            ///Set to out params the vector and the key
            key = CryptKey;
            vector = CryptVector;
            ///Encypt the file
            EncryptFile(clearFile, encryptedFile);
        }
        /// <summary>
        /// Encrypts the file.
        /// </summary>
        /// <param name="clearFile">The clear file.</param>
        /// <param name="encryptedFile">The encrypted file.</param>
        public static void EncryptFile(
            string clearFile,
            string encryptedFile)
        {
            FileStream fsFileOut = File.Create(encryptedFile);
            // This object links data streams to cryptographic values
            CryptoStream csEncrypt = new CryptoStream(fsFileOut, CryptAlgorithm.CreateEncryptor(), CryptoStreamMode.Write);
            // This stream writer will write the new file
            StreamWriter swEncStream = new StreamWriter(csEncrypt);
            // This stream reader will read the file to encrypt
            StreamReader srFile = new StreamReader(clearFile);
            // Loop through the file to encrypt, line by line
            string currLine = srFile.ReadLine();
            while (currLine != null)
            {
                // Write to the encryption stream
                swEncStream.Write(currLine);
                currLine = srFile.ReadLine();
            }
            // Wrap things up
            srFile.Close();
            swEncStream.Flush();
            swEncStream.Close();


        }
        #endregion

        #region DecryptFile
        /// <summary>
        /// Decrypts the file.
        /// </summary>
        /// <param name="clearFile">The clear file.</param>
        /// <param name="encryptedFile">The encrypted file.</param>
        /// <param name="key">The key.</param>
        /// <param name="vector">The vector.</param>
        public static void DecryptFile(
            string clearFile,
            string encryptedFile,
            string key,
            string vector)
        {
            CryptKey = key;
            CryptVector = vector;

            DecryptFile(clearFile, encryptedFile);
        }
        /// <summary>
        /// Decrypts the file.
        /// </summary>
        /// <param name="clearFile">The clear file.</param>
        /// <param name="encryptedFile">The encrypted file.</param>
        public static void DecryptFile(
            string clearFile,
            string encryptedFile)
        {
            // The encrypted file
            FileStream fsFileIn = File.OpenRead(encryptedFile);
            // The decrypted file
            FileStream fsFileOut = File.Create(clearFile);

            // The cryptographic stream takes in the unecrypted file
            CryptoStream csEncrypt =
                    new CryptoStream(fsFileIn, CryptAlgorithm.CreateDecryptor(), CryptoStreamMode.Read);

            // Write the new unecrypted file
            StreamReader srCleanStream = new StreamReader(csEncrypt);
            StreamWriter swCleanStream = new StreamWriter(fsFileOut);
            swCleanStream.Write(srCleanStream.ReadToEnd());
            swCleanStream.Close();
            fsFileOut.Close();
            srCleanStream.Close();
        }
        #endregion

        #region Encrypt_Decrypt_DES

        static byte[] bytes = ASCIIEncoding.ASCII.GetBytes("ZeroCool");

        /// <summary>
        /// Encrypt a string.
        /// </summary>
        /// <param name="originalString">The original string.</param>
        /// <returns>The encrypted string.</returns>
        /// <exception cref="ArgumentNullException">This exception will be 
        /// thrown when the original string is null or empty.</exception>
        public static string EncryptDES(string originalString)
        {
            if (String.IsNullOrEmpty(originalString))
            {
                throw new ArgumentNullException
                       ("The string which needs to be encrypted can not be null.");
            }
            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream,
                cryptoProvider.CreateEncryptor(bytes, bytes), CryptoStreamMode.Write);
            StreamWriter writer = new StreamWriter(cryptoStream);
            writer.Write(originalString);
            writer.Flush();
            cryptoStream.FlushFinalBlock();
            writer.Flush();
            return Convert.ToBase64String(memoryStream.GetBuffer(), 0, (int)memoryStream.Length);
        }


        /// <summary>
        /// Decrypt a crypted string.
        /// </summary>
        /// <param name="cryptedString">The crypted string.</param>
        /// <returns>The decrypted string.</returns>
        /// <exception cref="ArgumentNullException">This exception will be thrown 
        /// when the crypted string is null or empty.</exception>
        public static string DecryptDES(string cryptedString)
        {
            if (String.IsNullOrEmpty(cryptedString))
            {
                throw new ArgumentNullException
                   ("The string which needs to be decrypted can not be null.");
            }
            else
            {
                DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
                MemoryStream memoryStream = new MemoryStream
                        (Convert.FromBase64String(cryptedString));
                CryptoStream cryptoStream = new CryptoStream(memoryStream,
                    cryptoProvider.CreateDecryptor(bytes, bytes), CryptoStreamMode.Read);
                StreamReader reader = new StreamReader(cryptoStream);
                return reader.ReadToEnd();
            }
        }
        #endregion Encrypt_Decrypt_DES
    }
}
