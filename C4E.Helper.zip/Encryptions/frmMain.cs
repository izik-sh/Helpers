﻿using C4E.V4.Common.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Encryptions
{
    public partial class frmMain : Form
    {
        byte[] passwordBytes;

        public frmMain()
        {
            InitializeComponent();
            passwordBytes = GetPasswordBytes("");
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                txtResults.Text = EncryptionTools.DecryptDES(txtSource.Text);
                AddHistory();            
            }
            catch (Exception ex)
            {
                txtMessage.Text = ex.Message;
            }
        }

        private void btnEncryptDES_Click(object sender, EventArgs e)
        {
            try
            {
                txtResults.Text = EncryptionTools.EncryptDES(txtSource.Text);
                AddHistory();
            }
            catch (Exception ex)
            {
                txtMessage.Text = ex.Message;
            }
        }

        private void AddHistory()
        {
            gvHistory.Rows.Add(txtSource.Text, txtResults.Text);
        }

        private void btnDecryptAES_Click(object sender, EventArgs e)
        {

            try
            {
                txtResults.Text = AES.Decrypt(txtSource.Text, passwordBytes);
                AddHistory();
            }
            catch (Exception ex)
            {
                txtMessage.Text = ex.Message;
            }
        }

        private byte[] GetPasswordBytes(string secureTextBox)
        {
            byte[] ba = null;

            if (secureTextBox.Length == 0)
                ba = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

            return System.Security.Cryptography.SHA256.Create().ComputeHash(ba);
        }

        private void btnEncryptAES_Click(object sender, EventArgs e)
        {
            try
            {
                txtResults.Text = AES.Encrypt(txtSource.Text, passwordBytes);
                AddHistory();
            }
            catch (Exception ex)
            {
                txtMessage.Text = ex.Message;
            }
        }

        private void txtResults_MouseClick(object sender, MouseEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtResults.Text))
            {
                Clipboard.SetText(txtResults.Text);
                statusStrip.Items[0].Text = "This text was copied to clipboard: " + txtResults.Text;
            }
        }

        private void txtSource_MouseClick(object sender, MouseEventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtSource.Text))
            //{
            //    Clipboard.SetText(txtSource.Text);
            //    statusStrip.Items[0].Text = "This text was copied to clipboard: " + txtSource.Text;
            //}
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
        }

        private void About_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Created by Izik Shtemer", "About");
        }
    }
}
