﻿namespace Encryptions
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.txtSource = new System.Windows.Forms.TextBox();
            this.txtResults = new System.Windows.Forms.TextBox();
            this.lblSource = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            this.btnDecryptDES = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.btnEncryptDES = new System.Windows.Forms.Button();
            this.btnDecryptAES = new System.Windows.Forms.Button();
            this.btnEncryptAES = new System.Windows.Forms.Button();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.gvHistory = new System.Windows.Forms.DataGridView();
            this.source = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.results = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.About = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvHistory)).BeginInit();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSource
            // 
            this.txtSource.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSource.Location = new System.Drawing.Point(12, 48);
            this.txtSource.Multiline = true;
            this.txtSource.Name = "txtSource";
            this.txtSource.Size = new System.Drawing.Size(610, 77);
            this.txtSource.TabIndex = 0;
            this.txtSource.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtSource_MouseClick);
            // 
            // txtResults
            // 
            this.txtResults.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtResults.Location = new System.Drawing.Point(12, 211);
            this.txtResults.Multiline = true;
            this.txtResults.Name = "txtResults";
            this.txtResults.ReadOnly = true;
            this.txtResults.Size = new System.Drawing.Size(610, 87);
            this.txtResults.TabIndex = 1;
            this.txtResults.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtResults_MouseClick);
            // 
            // lblSource
            // 
            this.lblSource.AutoSize = true;
            this.lblSource.Location = new System.Drawing.Point(12, 31);
            this.lblSource.Name = "lblSource";
            this.lblSource.Size = new System.Drawing.Size(46, 15);
            this.lblSource.TabIndex = 2;
            this.lblSource.Text = "Source ";
            // 
            // lblResults
            // 
            this.lblResults.AutoSize = true;
            this.lblResults.Location = new System.Drawing.Point(12, 193);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(44, 15);
            this.lblResults.TabIndex = 3;
            this.lblResults.Text = "Results";
            // 
            // btnDecryptDES
            // 
            this.btnDecryptDES.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDecryptDES.Location = new System.Drawing.Point(104, 132);
            this.btnDecryptDES.Name = "btnDecryptDES";
            this.btnDecryptDES.Size = new System.Drawing.Size(86, 23);
            this.btnDecryptDES.TabIndex = 4;
            this.btnDecryptDES.Text = "DecryptDES";
            this.btnDecryptDES.UseVisualStyleBackColor = false;
            this.btnDecryptDES.Click += new System.EventHandler(this.btnDecrypt_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(12, 459);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(53, 15);
            this.lblMessage.TabIndex = 6;
            this.lblMessage.Text = "Message";
            // 
            // txtMessage
            // 
            this.txtMessage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMessage.Location = new System.Drawing.Point(12, 479);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(610, 87);
            this.txtMessage.TabIndex = 5;
            // 
            // btnEncryptDES
            // 
            this.btnEncryptDES.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnEncryptDES.Location = new System.Drawing.Point(12, 132);
            this.btnEncryptDES.Name = "btnEncryptDES";
            this.btnEncryptDES.Size = new System.Drawing.Size(86, 23);
            this.btnEncryptDES.TabIndex = 7;
            this.btnEncryptDES.Text = "EncryptDES";
            this.btnEncryptDES.UseVisualStyleBackColor = false;
            this.btnEncryptDES.Click += new System.EventHandler(this.btnEncryptDES_Click);
            // 
            // btnDecryptAES
            // 
            this.btnDecryptAES.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnDecryptAES.Location = new System.Drawing.Point(104, 161);
            this.btnDecryptAES.Name = "btnDecryptAES";
            this.btnDecryptAES.Size = new System.Drawing.Size(86, 23);
            this.btnDecryptAES.TabIndex = 8;
            this.btnDecryptAES.Text = "DecryptAES";
            this.btnDecryptAES.UseVisualStyleBackColor = false;
            this.btnDecryptAES.Click += new System.EventHandler(this.btnDecryptAES_Click);
            // 
            // btnEncryptAES
            // 
            this.btnEncryptAES.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnEncryptAES.Location = new System.Drawing.Point(12, 161);
            this.btnEncryptAES.Name = "btnEncryptAES";
            this.btnEncryptAES.Size = new System.Drawing.Size(86, 23);
            this.btnEncryptAES.TabIndex = 9;
            this.btnEncryptAES.Text = "EncryptAES";
            this.btnEncryptAES.UseVisualStyleBackColor = false;
            this.btnEncryptAES.Click += new System.EventHandler(this.btnEncryptAES_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip.Location = new System.Drawing.Point(0, 577);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.statusStrip.Size = new System.Drawing.Size(639, 22);
            this.statusStrip.TabIndex = 10;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // gvHistory
            // 
            this.gvHistory.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gvHistory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gvHistory.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.gvHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.source,
            this.results});
            this.gvHistory.Location = new System.Drawing.Point(12, 314);
            this.gvHistory.Margin = new System.Windows.Forms.Padding(2);
            this.gvHistory.Name = "gvHistory";
            this.gvHistory.RowHeadersWidth = 62;
            this.gvHistory.RowTemplate.Height = 33;
            this.gvHistory.Size = new System.Drawing.Size(609, 135);
            this.gvHistory.TabIndex = 11;
            // 
            // source
            // 
            this.source.HeaderText = "Source";
            this.source.MinimumWidth = 8;
            this.source.Name = "source";
            this.source.ReadOnly = true;
            // 
            // results
            // 
            this.results.HeaderText = "Results";
            this.results.MinimumWidth = 8;
            this.results.Name = "results";
            this.results.ReadOnly = true;
            // 
            // menuStrip
            // 
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.About});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip.Size = new System.Drawing.Size(639, 24);
            this.menuStrip.TabIndex = 12;
            this.menuStrip.Text = "menuStrip1";
            // 
            // About
            // 
            this.About.Name = "About";
            this.About.Size = new System.Drawing.Size(52, 22);
            this.About.Text = "About";
            this.About.Click += new System.EventHandler(this.About_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 599);
            this.Controls.Add(this.gvHistory);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.btnEncryptAES);
            this.Controls.Add(this.btnDecryptAES);
            this.Controls.Add(this.btnEncryptDES);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.btnDecryptDES);
            this.Controls.Add(this.lblResults);
            this.Controls.Add(this.lblSource);
            this.Controls.Add(this.txtResults);
            this.Controls.Add(this.txtSource);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Encryption Tools";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvHistory)).EndInit();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtSource;
        private TextBox txtResults;
        private Label lblSource;
        private Label lblResults;
        private Button btnDecryptDES;
        private Label lblMessage;
        private TextBox txtMessage;
        private Button btnEncryptDES;
        private Button btnDecryptAES;
        private Button btnEncryptAES;
        private StatusStrip statusStrip;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private DataGridView gvHistory;
        private DataGridViewTextBoxColumn source;
        private DataGridViewTextBoxColumn results;
        private MenuStrip menuStrip;
        private ToolStripMenuItem About;
    }
}